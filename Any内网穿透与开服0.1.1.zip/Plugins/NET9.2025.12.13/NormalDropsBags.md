# NormalDropsBags 普通难度掉落宝藏袋

- 作者：beerik94，羽学  
- 出处: https://github.com/beerik94/NormalBossBags  
- 这是一个Tshock服务器插件主要用于：  
- 让普通模式的BOSS掉宝藏袋  
- 仅影响普通难度地图，如果启用了专家或大师，则不执行任何操作。  


## 指令
```
暂无
```

## 配置

```
暂无
```

## 更新日志

### v1.3.1.0
- 适配.net 6.0

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love