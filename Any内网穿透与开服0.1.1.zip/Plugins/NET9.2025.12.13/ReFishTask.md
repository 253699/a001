# ReFishTask 刷新渔夫任务

- 作者: onusai 羽学
- 出处: [tshock-quest-fish-unlimited](https://github.com/onusai/tshock-quest-fish-unlimited)
- 当你完成渔夫任务时可无限接渔夫任务
- 配置项支持是否不更换任务鱼


## 指令
```
暂无
```

## 配置
> 配置文件位置：tshock/刷新渔夫任务.json
```json5
{
  "是否切换任务鱼（关掉就可以1种鱼刷1天）": true
}
```

## 更新日志
### v1.4.2
- 添加英文翻译

### v1.4.1
- 完善卸载函数

### v1.0.4
- 加入了配置项【是否切换任务鱼】
- 修复重进服提示任务已完成问题
- 修复会更换出不属于当前进度阶段的任务鱼问题
- 修复1人完成渔夫任务后，另1个人也提示完成问题



## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love