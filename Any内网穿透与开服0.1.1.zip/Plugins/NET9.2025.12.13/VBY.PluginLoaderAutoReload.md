# VBY.PluginLoaderAutoReload VBY自动重载

- 作者: xuyuwtu
- 出处: [MyPlugin](https://github.com/xuyuwtu/MyPlugin)
- VBY.PluginLoader的扩展, 当PluginLoader文件夹有插件改动时, 自动热重载插件

> [!NOTE]  
> 本插件需要`VBY.PluginLoader`前置


## 更新日志

```
无
```

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
