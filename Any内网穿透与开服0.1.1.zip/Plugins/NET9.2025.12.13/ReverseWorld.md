# ReverseWorld 世界反转和全图放置地雷

- 作者: 1413, 肝帝熙恩
- 出处: TShock中文官方群
- 让整个世界的方块倒过来
- 还可以随机放置地雷

## 指令


| 指令              | 别名            |       权限             | 说明         |
|-------------------|:---------------------:|:------------:|:---------------:|
| /reverseworld [kick]    | rw 或  反转世界            | tofout.reverseworld   | 反转整个世界的方向和地形，如果带参数kick将玩家全部踢出     |
| /placelandmine [数量]    | plm 或  放置地雷           | tofout.placelandmine  | 在玩家当前位置放置地雷     |



## 配置

```json5
暂无
```

## 更新日志

### v1.0.2
- 添加了一个可选参数kick，使用可以踢出全部玩家，不使用则是为玩家更新图格


## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
