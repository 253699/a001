# Respawn 原地复活

- 作者: leader，肝帝熙恩
- 出处: Tshock官方中文群
- 原地复活，复活时间与tshock自带config内容相同

## 指令

```
暂无
```

## 配置

```
暂无
```

## 更新日志

### v1.0.0
- 添加插件

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love