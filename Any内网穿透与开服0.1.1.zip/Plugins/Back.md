# Back 回到死亡点

- 作者: Megghy，肝帝熙恩
- 出处: TShock中文官方群聊
- 可以返回上次玩家的死亡地点，可自定义冷却时间



## 指令

| 语法    |  权限  |   说明   |
|-------|:----:|:------:|
| /back | back | 返回死亡地点 |

## 配置
> 配置文件位置：tshock/Back.zh-CN.json
```json5
{
  "back冷却时间": 20
}
```
## 更新日志


### v1.0.0.8
- 准备更新TS 5.2.1
- 修正文档
### v1.0.0.5
- 更新英文翻译
### v1.0.0.4
- 补全卸载函数

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
