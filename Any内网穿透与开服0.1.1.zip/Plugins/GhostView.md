﻿# GhostView 鬼魂观战

- 作者: Eustia
- 出处: 无
- 死亡后能在鬼魂状态下观战，阻止玩家重连刷新复活cd


## 指令
```
无
```
## 配置
> 配置文件位置：tshock/config.json
```json5
{
  "Settings": {
    // ... 其他配置项 ...
    "RespawnSeconds": 5,
    "RespawnBossSeconds": 20,
    // ... 其他配置项 ...
  }
}
```

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
