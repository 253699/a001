# JourneyUnlock 解锁旅途物品

- 作者: Maxthegreat99，肝帝熙恩汉化
- 出处: [github](https://github.com/Maxthegreat99/journeyUnlock)
- 解锁旅途物品，可以一键解锁全部物品

## 更新日志

### v1.0.0.2
- 只是改大写名字而已
### v1.0.1.1
- 补全卸载函数

## 指令

| 语法           |        权限         |   说明   |
| -------------- | :-----------------: | :------: |
| /journeyunlock 或 /junlock 或 /i解锁" |  journeyunlock.unlock  | 给自己解锁物品|
| /unlockfor 或 /unlockf 或 /g解锁玩家" |  journeyunlock.unlockfor  | 给别人解锁物品|

## 配置

```
暂无
```
## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
