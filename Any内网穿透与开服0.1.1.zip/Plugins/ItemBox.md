# ItemBox 物品盒子

- 作者: 2409 & Cai
- 出处: XSB插件邮件部分
- 或者叫离线背包更好？但是英文名不知道怎么取诶。

## 指令

| 语法             |       权限       |    说明     |
|----------------|:--------------:|:---------:|
| "cbox", "领盒子"  | ItemBox.claim  |  领取盒子物品   |
| "gbox", "给盒子"  |  ItemBox.give  | 赠送盒子到指定玩家 |
| "rbox", "重置盒子" | ItemBox.remove |  清空所有盒子   |

## 配置
```
无
```

## 更新日志

### v2024.10.3
- 初次分离提交

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
