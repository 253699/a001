﻿# HardPlayerDrop 硬核死亡掉生命水晶

- 作者: onusai 羽学
- 出处: [tshock-hc-drop-hearts](https://github.com/onusai/tshock-hc-drop-hearts)
- 根据玩家血量计算死亡后会掉落多少生命水晶（因为硬核死亡在服务器会把玩家重置为初始状态）

## 指令

```
暂无
```

## 配置
```json5
暂无
```

## 更新日志

### v1.0.0 
- 修复生命水晶掉不出来的问题

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
