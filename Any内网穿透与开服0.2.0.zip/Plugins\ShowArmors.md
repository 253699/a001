# ShowArmors 展示装备

- 作者: Ak，肝帝熙恩
- 出处: bbstr.net，[github](https://github.com/yf836760/ShowArmors)
- 发送自己的装备配置到聊天框
- 插件仅显示装备栏的物品信息，不包括其他栏位的物品信息。
- 科普：<>是必填;[]是选填，不填就为默认值


## 指令

| 语法       |     别名      |     权限     |  说明  |
|----------|:-----------:|:----------:|:----:|
| /装备 [玩家] | /show 或 /zb | ShowArmors | 显示装备 |

## 配置

```
暂无
```

## 更新日志

### v1.0.2
- 完善卸载函数，简化代码


## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love