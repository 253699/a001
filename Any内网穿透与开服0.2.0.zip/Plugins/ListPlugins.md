# ListPlugins 查看插件列表

- 作者: iheart ，羽学，肝帝熙恩
- 出处: 未知
- 用指令查已装插件，显示插件名字，作者，描述

## 指令

| 语法              |     权限     |  说明   |
|-----------------|:----------:|:-----:|
| /插件列表 或 /pllist | ListPlugin | 查已装插件 |

## 配置
```
暂无
```

## 更新日志

### v1.0.5
- 完善卸载函数
### v1.0.4
- 显示插件版本

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
