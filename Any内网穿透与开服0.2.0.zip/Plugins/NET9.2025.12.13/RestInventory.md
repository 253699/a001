# RestInventory 提供 Rest 查背包接口

- 作者: 少司命
- 出处: 无
- 查询玩家背包

## Rest API

| 路径          |       权限       | 说明  |
|-------------|:--------------:|:---:|
| /beanInvsee | beanInvsee.use | 查背包 |

## 配置

```json
暂无
```

## 更新日志


### v1.0.0.2
完善rest卸载函数

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
