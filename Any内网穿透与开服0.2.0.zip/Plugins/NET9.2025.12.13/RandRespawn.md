# RandReSpawn 随机出生点

- 作者: 1413,肝帝熙恩
- 出处: Tshock官方中文群
- 任何回到出生点的操作都会被随机传送

## 指令

```
暂无
```

## 配置

```json
暂无
```

## 更新日志

### v1.0.2
- 添加英文翻译
### v1.0.1
- 完善卸载函数


## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love