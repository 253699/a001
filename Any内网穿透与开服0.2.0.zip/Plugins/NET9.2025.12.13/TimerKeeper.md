# TimerKeeper 保存计时器状态

- 作者: Cai
- 出处: [github](https://github.com/THEXN/CaiPlugins)
- 保存电路计时器状态，重启后自动开启计时器  
> [!NOTE]  
> 如果重置地图，你需要删除数据库表格`TimerKeeper`来重置计时器保存记录

## 指令
```
暂无
```

## 配置
```
暂无
```
## 更新日志
### v2024.9.8.1
- 添加英文翻译

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
