# RolesModifying 修改玩家背包

- 作者: 少司命
- 出处: 无
- 修改玩家背包

## 指令

| 路径               |             权限             |  说明  |
|------------------|:--------------------------:|:----:|
| /rm 或 /修改 或 /查背包 | tshock.user.rolesmodifying | 修改背包 |

## 配置

```json
暂无
```

## 更新日志

### v1.0.5
- 适配TShock 5.2.3
### v1.0.4
- 添加错误提示，修正文档
### v1.0.1
- 完善卸载函数

## 反馈

- 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 国内社区 trhub.cn 或 TShock 官方群等
