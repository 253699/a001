# VBY.Common VBY通用库

- 作者: xuyuwtu
- 出处: [MyPlugin](https://github.com/xuyuwtu/MyPlugin)
- VBY插件的前置库



## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love
