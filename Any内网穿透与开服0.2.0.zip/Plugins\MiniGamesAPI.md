# MiniGamesAPI 豆沙小游戏API
- 作者: [Bean_Paste]https://gitee.com/Crafty/projects,羽学
- 出处: [bbstr]https://www.bbstr.net/r/107/
- MiniGamesAPI的开发初衷旨在为插件开发者提供快速的小游戏整体部署，此插件内置了许多小游戏插件常用到的类以及代码。


## 指令
```
暂无
```

## 配置

```
暂无
```

## 更新日志

### v1.1.5
- 适配TShock 5.2.3
### v1.0.8
- 适配.NET 6.0
- 修复区域相关BUG
- 删除一些无用的方法
- 新增MiniPlayer.Godmode方法方便让玩家进入无敌模式
- 新增MiniPlayer.Creative方法提供一个快速解锁（上锁）旅行全物品的方式
- 修复ZombleMode中强制退出无法再进入服务器BUG

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love